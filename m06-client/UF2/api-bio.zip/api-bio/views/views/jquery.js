/**
   * @file jquey.js
   * @version 1.1
   * @author Alumne DAW Bio2
*/

// Quan el DOM estigui ready
$(document).ready(function() {
    // Missatge
    var response = "";
    $("modify").addEventListener("click", function(){
        // Métode Ajax
        $.ajax({
            type: "GET",
            url:"", 
            async:false,

            // Some data
            accountType:{id:1, type:"Soliday account"},

            // Message in case of success
            success: function(text){
                response = text;
            },

            // Message in case of error
            // Si la petición falla
            error:  function(xhr, status){
                alert("Problem detected");
            },

            // Sí la petición tiene success o error
            complete : function(xhr, status){
                alert('Petición realizada');
            }

        })
    });
});