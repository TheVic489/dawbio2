/**
   * @file Manages the account class
   * @version 1.1
   * @author Alumne DAW Bio2
*/

/**
   * @class account with all data
   * 
 */
class accountType{
    countructor(id, type){
        this.id = id;
        this.type = type;
    }

    // Getters
    get id(){
        return this.id;
    }

    get type(){
        return this.type;
    }
}


/**
   * @class account with all data
   * 
 */
class account{

    // Constructor
    constructor(DNIClient, fullNameClient, accountType, amount, clientType, entryDate){
        this.id = DNIClient;
        this.fullNameClient = fullNameClient;
        this.accountType = accountType;
        this.amount = amount;
        this.clientType = clientType;
        this.entryDate = entryDate;
    }

    // Getters
    get DNIClient(){
        return this.DNIClient;
    }

    get fullNameClient(){
        return this.fullNameClient;
    }

    get accountType(){
        return this.accountType;
    }

    get amount(){
        return this.amount;
    }

    get entryDate(){
        return this.entryDate();
    }

    // Setters
    set DNIClient(DNIClient){
        this.DNIClient = DNIClient;
    }

    set fullNameClient(fullNameClient){
        this.fullNameClient = fullNameClient;
    }

    set accountType(accountType){
        this.accountType = accountType;
    }

    set amount(amount){
        this.amount = amount;
    }

    set entryDate(entryDate){
        this.entryDate = entryDate();
    }

    // Methods
    entryDate(){
        return this.datepicker();
    }

    loadData(){
    ;
    }
}
