/**
   * @file Manages the account class
   * @version 1.1
   * @author Alumne DAW Bio2
*/


/**
   * @class account with all data
   * 
 */
class Project{

    // Constructor
    constructor(name, description, category, data, lang){
        this.name = name;
        this.description = description;
        this.category = category;
        this.data= data;
        this.lang = lang;
    }

}
