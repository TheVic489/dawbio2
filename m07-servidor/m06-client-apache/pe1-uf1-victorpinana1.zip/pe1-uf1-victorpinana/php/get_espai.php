<?php
// Variables, arrays...
$destinations = [ 0 => "Despatx de direcció", 1 => "Sala de videoconferències", 2 => "Magatzem"];
echo json_encode($destinations);

?>