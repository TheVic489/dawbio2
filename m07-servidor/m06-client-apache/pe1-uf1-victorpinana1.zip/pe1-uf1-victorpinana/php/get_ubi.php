<?php
// Variables, arrays...
$destinations = [ 0 => "Logística (Madrid)", 1 => "Seu Central (Barcelona)"];
echo json_encode($destinations);

?>