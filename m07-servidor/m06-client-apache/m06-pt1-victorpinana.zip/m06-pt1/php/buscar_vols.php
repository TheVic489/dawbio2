<?php
// Variables, arrays...
$destinations = [ 0 => "Barcelona", 1 => "València", 2 => "Madrid"];
echo json_encode($destinations);

?>