<nav>
    <ul>
        <li><a style="color: burlywood">Store application</a></li>
        <li><a href="index.php?action=home">Home</a></li>
        <li><a href="index.php?action=user/listAll">List all users</a></li>
        <li><a href="index.php?action=user/form">User form</a></li>
        <li><a href="index.php?action=login/form">Login</a></li>
        <li><a href="index.php?action=logout/form">Logout</a></li>
    </ul>
</nav>