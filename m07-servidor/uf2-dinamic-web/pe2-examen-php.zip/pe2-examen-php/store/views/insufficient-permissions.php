
<?php
$message = $params['message']??'';
echo "<h3 style='color:red'>$message</h3>";
