<p class="footer">Store manager &copy; ProvenSoft 2023</p>

