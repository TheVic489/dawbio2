<?php
echo "<h3>Welcome to Store manager</h3>";
echo "<p> In this application you will be able to manage users, products and warehouses.</p>";

//TODO add some content, such as text and images that fit a main page for a store web page.
