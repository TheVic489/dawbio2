<?php
/**
 * Searches username and password in user's file
 * @param string $username the username to search
 * @param string $password the password to search
 * @return array with the data of the user or empty array if dosent find.
 */
function searchUser(string $username, string $password): array {
    $filename = "files/users.txt";
    $delimiter = ";";
    $result = [];
    if (\file_exists($filename) && \is_readable($filename)) {
        $handle = \fopen($filename, 'r');  //returns false on error.
        if ($handle) {
            while (!\feof($handle)) {
                //$line = \fgets($handle);
                fscanf($handle, "%s\n", $line);
                if ($line) {
                    list($usr, $psw, $role, $fname, $lname) = \explode($delimiter, $line);
                    if (($usr==$username) && ($psw==$password)) {
                        $result = [
                            'username' => $usr,
                            'password' => $psw, 
                            'role' => $role, 
                            'fname' => $fname, 
                            'lname' => $lname
                        ];
                        break;
                    }
                }
            }
            \fclose($handle);            
        }
    }  
    return $result;
}